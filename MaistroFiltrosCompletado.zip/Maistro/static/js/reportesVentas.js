document.addEventListener("DOMContentLoaded", function () {
    const filtroIcono = document.getElementById("filtro");
    const menuFiltros = document.getElementById("menuFiltros");

    filtroIcono.addEventListener("click", () => {
        let overlay = document.querySelector(".overlay");

        if (!overlay) {
            overlay = document.createElement("div");
            overlay.className = "overlay";
            document.body.appendChild(overlay);

            overlay.addEventListener("click", () => {
                menuFiltros.classList.remove("activo");
                menuFiltros.classList.add("oculto"); // 👈 importante
                overlay.remove();
            });
        }

        menuFiltros.classList.remove("oculto"); // 👈 quita la clase que impide mostrar
        menuFiltros.classList.add("activo");
    });

    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
            const overlay = document.querySelector(".overlay");
            if (overlay && menuFiltros.classList.contains("activo")) {
                menuFiltros.classList.remove("activo");
                menuFiltros.classList.add("oculto"); // 👈 también aquí
                overlay.remove();
            }
        }
    });
});

