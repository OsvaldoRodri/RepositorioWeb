document.addEventListener("DOMContentLoaded", function () {
    const filtroIcono = document.getElementById("filtro");
    const menuFiltros = document.getElementById("menuFiltros");
    const form = document.getElementById("menuFiltros");
    const inputBusqueda = document.getElementById("inputBusqueda");

    if (!filtroIcono || !menuFiltros || !form) return;

    // Mostrar menú de filtros
    filtroIcono.addEventListener("click", () => {
        let overlay = document.querySelector(".overlay");

        if (!overlay) {
            overlay = document.createElement("div");
            overlay.className = "overlay";
            document.body.appendChild(overlay);

            overlay.addEventListener("click", cerrarFiltros);
        }

        menuFiltros.classList.remove("oculto");
        menuFiltros.classList.add("activo");
    });

    // Cerrar menú con ESC
    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
            cerrarFiltros();
        }
    });

    function cerrarFiltros() {
        const overlay = document.querySelector(".overlay");

        if (menuFiltros.classList.contains("activo")) {
            menuFiltros.classList.remove("activo");
            menuFiltros.classList.add("oculto");
            if (overlay) overlay.remove();
        }
    }

    // Guardar filtros en localStorage al enviar
    form.addEventListener("submit", function (e) {
        e.preventDefault();

        const filtros = {
            min: form.querySelector('[name="min"]').value.trim(),
            max: form.querySelector('[name="max"]').value.trim(),
            tipo: form.querySelector('[name="tipo"]').value.trim(),
            marca: form.querySelector('[name="marca"]').value.trim(),
            orden: form.querySelector('[name="orden"]').value.trim()
        };

        const hayFiltros = Object.values(filtros).some(v => v !== "");

        if (hayFiltros) {
            localStorage.setItem("filtrosActivos", JSON.stringify(filtros));
        } else {
            localStorage.removeItem("filtrosActivos");
        }

        cerrarFiltros();
    });

    // Restaurar filtros si existen
    const datosGuardados = localStorage.getItem("filtrosActivos");
    if (datosGuardados) {
        const valores = JSON.parse(datosGuardados);
        form.querySelector('[name="min"]').value = valores.min || "";
        form.querySelector('[name="max"]').value = valores.max || "";
        form.querySelector('[name="tipo"]').value = valores.tipo || "";
        form.querySelector('[name="marca"]').value = valores.marca || "";
        form.querySelector('[name="orden"]').value = valores.orden || "";
    }

    // Detectar búsqueda al presionar Enter
    if (inputBusqueda) {
        inputBusqueda.addEventListener("keydown", function (e) {
            if (e.key === "Enter") {
                e.preventDefault();

                const term = inputBusqueda.value.trim();
                const filtros = localStorage.getItem("filtrosActivos");

                const params = new URLSearchParams();

                if (term) {
                    params.append("term", term);
                }

                if (filtros) {
                    const valores = JSON.parse(filtros);
                    if (valores.min) params.append("min", valores.min);
                    if (valores.max) params.append("max", valores.max);
                    if (valores.tipo) params.append("tipo", valores.tipo);
                    if (valores.marca) params.append("marca", valores.marca);
                    if (valores.orden) params.append("orden", valores.orden);
                }
                localStorage.removeItem("filtrosActivos");
                window.location.href = "/filtros?" + params.toString();
            }
        });
    }
});
