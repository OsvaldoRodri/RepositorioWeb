document.addEventListener("DOMContentLoaded", function () {
    const filtroIcono = document.getElementById("filtro");
    const menuFiltros = document.getElementById("menuFiltros");
    const form = document.getElementById("menuFiltros");

    if (!filtroIcono || !menuFiltros || !form) return;

    filtroIcono.addEventListener("click", () => {
        let overlay = document.querySelector(".overlay");

        if (!overlay) {
            overlay = document.createElement("div");
            overlay.className = "overlay";
            document.body.appendChild(overlay);

            overlay.addEventListener("click", () => {
                cerrarMenuFiltros();
            });
        }

        menuFiltros.classList.add("activo");
    });

    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
            cerrarMenuFiltros();
        }
    });

    function cerrarMenuFiltros() {
        const overlay = document.querySelector(".overlay");
        if (menuFiltros.classList.contains("activo")) {
            menuFiltros.classList.remove("activo");
            setTimeout(() => overlay?.remove(), 300);
        }
    }

    form.addEventListener("submit", function (e) {
        e.preventDefault();

        const min = form.querySelector('[name="min"]').value.trim();
        const max = form.querySelector('[name="max"]').value.trim();
        const marca = form.querySelector('[name="marca"]').value.trim();
        const tipo = form.querySelector('[name="tipo"]').value.trim();
        const orden = form.querySelector('[name="orden"]').value.trim();
        const params = new URLSearchParams();
        const hayFiltros = min || max || marca || tipo || orden;
        const termFromURL = new URLSearchParams(window.location.search).get("term");
        const filtros = { min, max, marca, tipo, orden };

        if (termFromURL) {
            params.append("term", termFromURL);
        }

        if (min) params.append("min", min);
        if (max) params.append("max", max);
        if (marca) params.append("marca", marca);
        if (tipo) params.append("tipo", tipo);
        if (orden) params.append("orden", orden);

        if (hayFiltros) {
            console.log("Filtros activos:", { min, max, marca, tipo, orden });
            localStorage.setItem("filtrosActivos", JSON.stringify(filtros));
        } else {
            localStorage.removeItem("filtrosActivos");
        }
        window.location.href = "/filtros?" + params.toString();

        cerrarMenuFiltros();
    });

    // ✅ BÚSQUEDA FUNCIONAL (sin afectar filtros)
    const inputBusqueda = document.getElementById("inputBusqueda");
    const btnBuscar = document.getElementById("btnBuscar");

    function realizarBusqueda() {
        const texto = inputBusqueda?.value.trim();
        if (texto) {
            window.location.href = "/filtros?term=" + encodeURIComponent(texto);
        }
    }

    if (inputBusqueda) {
        inputBusqueda.addEventListener("keydown", function (e) {
            if (e.key === "Enter") {
                e.preventDefault();
                realizarBusqueda();
            }
        });
    }

    if (btnBuscar) {
        btnBuscar.addEventListener("click", realizarBusqueda);
    }
});
