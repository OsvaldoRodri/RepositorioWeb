from DataBase.db_config import db
from enum import Enum

class UserType(Enum):
    # Esta clase son los tipos de usuarios, que nos ayudarán a saber
    # que permisos tendrán los usuarios.
    ADMIN = "administrator"
    BUYER = "buyer"


class AuthProvider(Enum):
    EMAIL = "email"
    GOOGLE = "google"

# Tabla del Carrito de Compras
class User(db.Model):
    __tablename__ = "user"
    id_user = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    password = db.Column(db.String(120), nullable=False)
    user_type = db.Column(db.String(50), default=UserType.BUYER.value)
    provider_authentication = db.Column(db.String(50), default=AuthProvider.EMAIL.value)