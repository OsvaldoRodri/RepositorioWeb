from UserFiles.User import User
from DataBase.db_config import db
from UserFiles.User import UserType, AuthProvider


class UserManager:

    @staticmethod
    def createUser(name, email, password, user_type=UserType.BUYER.value, provider=AuthProvider.EMAIL.value):
        user = User(
            name=name,
            email=email,
            password=password,
            user_type=user_type,
            provider_authentication=provider
        )
        db.session.add(user)
        db.session.commit()
        return user

    @staticmethod
    def getUser(userID):
        return User.query.get(userID)

    @staticmethod
    def getUserByEmail(email):
        return User.query.filter_by(email=email).first()


    @staticmethod
    def deleteUser(userID):
        user = User.query.get(userID)
        if user:
            db.session.delete(user)
            db.session.commit()


    @staticmethod
    def editUser(userID, **kwargs):
        user = User.query.get(userID)
        if user:
            for key, value in kwargs.items():
                if hasattr(user, key) and value is not None:
                    setattr(user, key, value)
            db.session.commit()
        return user