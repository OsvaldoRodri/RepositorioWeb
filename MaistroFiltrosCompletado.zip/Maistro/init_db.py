from AutoPartFiles.AutoPart import AutoPartCondition
from AutoPartFiles.CatalogManager import CatalogManager
from CartFiles.CartManager import CartManager
from UserFiles.UserManager import UserManager
from DataBase.db_config import app

if __name__ == '__main__':
    app.app_context().push()

    autoPart1 = CatalogManager.addAutoPart(
        name="Batería LTH",
        description="Batería de 12V para autos compactos",
        brand="LTH",
        model="LTH-45",
        year=2023,
        condition=AutoPartCondition.NEW,
        price=1250.0,
        stock=10,
        imagen_url="https://example.com/bateria_lth.jpg"
    )

    autoPart2 = CatalogManager.addAutoPart(
        name="Filtro de Aceite",
        description="Filtro compatible con autos Nissan y Toyota",
        brand="Bosch",
        model="O-123",
        year=2022,
        condition=AutoPartCondition.NEW,
        price=220.0,
        stock=30,
        imagen_url="https://example.com/filtro_aceite.jpg"
    )

    UserManager.createUser(
        name="Ana Torres",
        email="ana@example.com",
        password="ana123"
    )

    UserManager.createUser(
        name="Luis Pérez",
        email="luis@example.com",
        password="luis123"
    )

    user1 = UserManager.getUserByEmail("ana@example.com")
    user2 = UserManager.getUserByEmail("luis@example.com")

    cart1 = CartManager.getActiveCart(user1.id_user)
    cart2 = CartManager.getActiveCart(user2.id_user)

    CartManager.addItem(user1.id_user, autoPart1.id_autopart, 10, autoPart1.price)
    CartManager.addItem(user2.id_user, autoPart1.id_autopart, 7, autoPart1.price)
    CartManager.addItem(user2.id_user, autoPart2.id_autopart, 5, autoPart2.price)

    print("Datos creados exitosamente.")
