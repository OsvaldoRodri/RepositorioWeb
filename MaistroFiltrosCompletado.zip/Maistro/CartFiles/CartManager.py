from CartFiles.Cart import Cart
from DataBase.db_config import db
from CartFiles.Cart import CartItem


class CartManager:

    @staticmethod
    def getActiveCart(userID):
        cart = Cart.query.filter_by(id_user=userID).first()
        if not cart:
            cart = Cart(id_user=userID)
            db.session.add(cart)
            db.session.commit()
        return cart


    # Aquí puedes añadir un item si no está en la base de datos, y si ya hay uno con el mismo ID
    # entonces nada más se incrementa la cantidad
    @staticmethod
    def addItem(userID, autoPartID, amount, unitPrice):
        cart = CartManager.getActiveCart(userID)
        item = CartItem.query.filter_by(id_cart=cart.id_cart, id_autopart=autoPartID).first()
        if item:
            item.amount += amount
        else:
            item = CartItem(id_cart=cart.id_cart, id_autopart=autoPartID, amount=amount, unit_price=unitPrice)
            db.session.add(item)
        db.session.commit()
        return item

    @staticmethod
    def removeItem(userID, autoPartID, amount):
        cart = CartManager.getActiveCart(userID)
        item = CartItem.query.filter_by(id_cart=cart.id_cart, id_autopart=autoPartID).first()
        if item:
            item.amount -= amount
            if item.amount <= 0:
                db.session.delete(item)
            db.session.commit()


    @staticmethod
    def getCartTotal(userID, cartState):
        cart = Cart.query.filter_by(id_user=userID, state=cartState.value).first()
        if not cart:
            return 0.0
        return sum(item.amount * item.unit_price for item in cart.items)
