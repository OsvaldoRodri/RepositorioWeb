from DataBase.db_config import db
from enum import Enum

class CartState(Enum):
    # Esta clase es para poder obtener los estados de el carrito disponibles
    # y así no confundirse poniendolo diferente, con mayusculas, etc.
    ACTIVE = "active"
    PROCESS = "process"

# Tabla del Carrito de Compras
class Cart(db.Model):
    __tablename__ = "cart"
    __table_args__ = {'extend_existing': True}
    id_cart = db.Column(db.Integer, primary_key=True)
    id_user = db.Column(db.Integer, nullable=False)
    state = db.Column(db.String(20), default=CartState.ACTIVE.value)
    items = db.relationship("CartItem", backref="cart", cascade="all, delete")


# Items de el carrito
class CartItem(db.Model):
    __tablename__ = "cart_item"
    __table_args__ = {'extend_existing': True}
    id_cart_item = db.Column(db.Integer, primary_key=True)
    id_cart = db.Column(db.Integer, db.ForeignKey('cart.id_cart'))
    id_autopart = db.Column(db.Integer, nullable=False)
    amount = db.Column(db.Integer, default=0)
    unit_price = db.Column(db.Float, nullable=False)