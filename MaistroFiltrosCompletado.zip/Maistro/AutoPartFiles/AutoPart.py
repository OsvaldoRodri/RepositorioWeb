from DataBase.db_config import db, app
from enum import Enum

class AutoPartCondition(Enum):
    NEW = "new"
    USED = "used"

# Tabla de las partes de autos
class AutoPart(db.Model):
    __tablename__ = 'autopart'
    id_autopart = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, default="")
    description = db.Column(db.Text, default="")
    brand = db.Column(db.String(50), default="")
    model = db.Column(db.String(50), default="")
    year = db.Column(db.Integer)
    condition = db.Column(db.String(20), default="")
    price = db.Column(db.Float, nullable=False)
    stock = db.Column(db.Integer, default=0)
    imagen_url = db.Column(db.String(255))
    tipo = db.Column(db.String(50), default="")
    promocion = db.Column(db.Boolean, default=False)
