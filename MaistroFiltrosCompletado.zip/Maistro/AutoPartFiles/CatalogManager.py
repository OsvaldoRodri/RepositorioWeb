from AutoPartFiles.AutoPart import AutoPart
from DataBase.db_config import db
class CatalogManager:

    @staticmethod
    def getPromoAutoParts():
        return AutoPart.query.filter_by(promocion=True).all()


    @staticmethod
    def getAutoPart(autoPartID):
        autoPart = AutoPart.query.get(autoPartID)
        return autoPart

    @staticmethod
    def removeAutoPart(autoPartID, amount):
        autoPart = CatalogManager.getAutoPart(autoPartID)
        if autoPart:
            autoPart.stock -= amount
            if autoPart.stock <= 0:
                db.session.delete(autoPart)
            db.session.commit()

    @staticmethod
    def addAutoPart(name, description, brand, model, year, condition, price, stock, imagen_url):
        if isinstance(condition, Enum):
            condition = condition.value

        new_part = AutoPart(
            name=name,
            description=description,
            brand=brand,
            model=model,
            year=year,
            condition=condition,
            price = float(price),
            stock=stock,
            imagen_url=imagen_url
        )
        db.session.add(new_part)
        db.session.commit()
        return new_part

    @staticmethod
    def editAutoPart(autoPartID, **kwargs):
        autoPart = AutoPart.query.get(autoPartID)
        if autoPart:
            for key, value in kwargs.items():
                if hasattr(autoPart, key) and value is not None:
                    setattr(autoPart, key, value)
            db.session.commit()
        return autoPart

    @staticmethod
    def getAllAutoParts():
        return AutoPart.query.all()