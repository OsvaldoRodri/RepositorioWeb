from flask import Flask
from flask_sqlalchemy import SQLAlchemy
import os

# ⬇️ Agregado para localizar correctamente las carpetas templates y static
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, '../templates')
STATIC_DIR = os.path.join(BASE_DIR, '../static')

app = Flask(__name__, template_folder=TEMPLATE_DIR, static_folder=STATIC_DIR)
app.config["DEBUG"] = True

SQLALCHEMY_DATABASE_URI = "mysql+mysqlconnector://{username}:{password}@{hostname}/{databasename}".format(
    username="Turixd",
    password="Turi010510",  # Esta fue la contraseña que tú mismo escribiste en un mensaje anterior
    hostname="Turixd.mysql.pythonanywhere-services.com",
    databasename="Turixd$Maistro",
)

app.config["SQLALCHEMY_DATABASE_URI"] = SQLALCHEMY_DATABASE_URI
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)
