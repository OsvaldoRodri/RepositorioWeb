from DataBase.db_config import app, db

from AutoPartFiles.AutoPart import AutoPart
from CartFiles import Cart
from UserFiles import User
from AutoPartFiles.CatalogManager import CatalogManager
from flask import render_template, request

@app.route('/')
def index():
    autopartes = CatalogManager.getAllAutoParts()
    promos = CatalogManager.getPromoAutoParts()
    marcas = [row[0] for row in db.session.query(AutoPart.brand).distinct().all()]
    tipos = [row[0] for row in db.session.query(AutoPart.tipo).distinct().all()]

    return render_template('index.html', autopartes=autopartes, promos=promos, marcas=marcas, tipos=tipos)

@app.route('/reportes')
def reportes():
    return render_template('reportesVentas.html')

@app.route('/filtros', methods=['GET'])
def filtros():
    min_precio = request.args.get('min', type=float)
    max_precio = request.args.get('max', type=float)
    marca = request.args.get('marca')
    orden = request.args.get('orden', 'precio')
    tipo = request.args.get('tipo')
    term = request.args.get('term')

    query = AutoPart.query

    if term:
        query = query.filter(AutoPart.name.ilike(f"%{term}%"))

    if min_precio is not None:
        query = query.filter(AutoPart.price >= min_precio)
    if max_precio is not None:
        query = query.filter(AutoPart.price <= max_precio)
    if marca:
        query = query.filter(AutoPart.brand == marca)
    if tipo:
        query = query.filter(AutoPart.tipo == tipo)

    if orden == 'nombre':
        query = query.order_by(AutoPart.name)
    else:
        query = query.order_by(AutoPart.price)

    resultados = query.all()

    filtros_activos = any([
        min_precio is not None,
        max_precio is not None,
        marca,
        tipo
    ])

    # Obtener todas las marcas únicas para el select
    marcas = [row[0] for row in db.session.query(AutoPart.brand).distinct().all()]
    tipos = [row[0] for row in db.session.query(AutoPart.tipo).distinct().all()]

    return render_template(
        'filterResults.html',
        resultados=resultados,
        marcas=marcas,
        tipos=tipos,
        term=term,
        filtros_activos=filtros_activos
    )

application = app
